/*
    Viivi ja Wagner  widget - Fetches Viivi ja Wagner comic strip
    from <http://www.helsinginsanomat.fi/>
    Copyright (C) 2005 Juha Ollila 

    Viivi ja Wagner  widget is free software; you can redistribute
    it and/or modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; 
    version 2 of the License.

    Viivi ja Wagner  widget is distributed in the hope that it will
    be useful, but WITHOUT ANY WARRANTY; without even the implied
    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*/

var debug = false;
var timer = null;

if (window.widget)
{
    widget.onshow = onshow;
    widget.onhide = onhide;

}
function onshow () {
    if (timer == null) {
        viivi();
        timer = setInterval("viivi();", 5000);
    }
}

function viivi() {
   var req = new XMLHttpRequest();
   req.setRequestHeader("Cache-Control", "no-cache");
   req.onreadystatechange=function() { 
      if(debug) alert('onreadystatechange()');
      if (req.readyState==4) {
         if(req.status=200) {
            if(debug) alert('OK');
            var response=req.responseText;
            // V+V images now look like
            // /webkuva/sarjis/560/1305625083163?ts=154
            var start = response.indexOf('/webkuva/sarjis/');
            // actually this is 1 too long, but it just picks up the harmless ? at the end
            // which protects us a bit against the id length changing
            var img_name = response.substring(start, start+34);
	    if(debug) alert(img_name);
	          var viivi_image = document.getElementById('viivi_fig');
            viivi_image.src = "http://www.hs.fi"+img_name;
            viivi_image.width=600;
            viivi_image.height=203;
         } else {
            if(debug) alert("req.status: "+req.status);
         }
     } else {
        if(debug) alert("req.readyState: "+req.readyState);
     }
   }
   req.open("GET", "http://www.hs.fi/viivijawagner/", true);
   req.send(null);
}

function onhide () {
    if (timer != null) {
       clearInterval(timer);
       timer = null;
    }
}
function gotoHesari (event) {
    if(window.widget)
    {
        widget.openURL("http://www.hs.fi/viivijawagner/");
    }
}

